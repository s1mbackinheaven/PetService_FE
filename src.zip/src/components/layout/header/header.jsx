import './header.css'
import Logo from './logo';
import LoginButton from './loginbutton';
import MenuHeader from './menuheader';
import NavMenu from './menu';

const Header = () => {
    return (
        <div className='header'>
            <Logo />
            {/* <MenuHeader /> */}
            <NavMenu />
            <LoginButton />
        </div>
    );
}

export default Header