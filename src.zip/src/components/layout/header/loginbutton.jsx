import './loginbutton.css'

const LoginButton = () => {
    return (
        <div className='login-button'>
            <span>Login</span>
            <i className="fas fa-paper-plane"></i>
        </div>
    );
}

export default LoginButton