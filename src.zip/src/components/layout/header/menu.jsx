import { Menu, Dropdown } from 'antd';
import { DownOutlined } from '@ant-design/icons';
import './menu.css'

const serviceMenu = (
    <Menu>
        <Menu.Item><a href="#">Dịch Vụ Spa Thú Cưng</a></Menu.Item>
        <Menu.Item><a href="#">Dịch Vụ Thú Cưng Tại Nhà</a></Menu.Item>
        <Menu.Item><a href="#">Ưu Đãi Pet Service</a></Menu.Item>
        <Menu.Item><a href="#">Khách Sạn Thú Cưng</a></Menu.Item>
        <Menu.Item><a href="#">Dắt Chó Đi Dạo</a></Menu.Item>
    </Menu>
);

const shopMenu = (
    <Menu>
        <Menu.Item><a href='#'>Dành Cho Chó</a></Menu.Item>
        <Menu.Item><a href='#'>Dành Cho Mèo</a></Menu.Item>
        <Menu.Item><a href='#'>Phụ Kiện Thú Cưng</a></Menu.Item>
        <Menu.Item><a href='#'>Chăm Sóc Sức Khỏe</a></Menu.Item>
    </Menu>
);

const NavMenu = () => {
    return (
        <nav>
            <Menu mode="horizontal">
                <Menu.Item><a href="#">Trang Chủ</a></Menu.Item>
                <Menu.Item><a href="#">Giới Thiệu</a></Menu.Item>

                {/* Dropdown cho Dịch Vụ */}
                <Menu.Item>
                    <Dropdown overlay={serviceMenu}>
                        <a href="#">
                            Dịch Vụ <DownOutlined />
                        </a>
                    </Dropdown>
                </Menu.Item>

                <Menu.Item>
                    <Dropdown overlay={shopMenu}>
                        <a href="#">
                            Cửa Hàng <DownOutlined />
                        </a>
                    </Dropdown>
                </Menu.Item>
                <Menu.Item><a href="#">Blog</a></Menu.Item>
                <Menu.Item><a href="#">Liên Hệ</a></Menu.Item>
            </Menu>
        </nav>
    );
};

export default NavMenu;
