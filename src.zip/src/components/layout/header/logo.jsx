
const Logo = () => {
    return (
        <div className="logo">
            <img src="https://petservicehcm.com/wp-content/uploads/2019/11/Pet_logo.webp" alt="This is logo" />
        </div>
    );
}

export default Logo