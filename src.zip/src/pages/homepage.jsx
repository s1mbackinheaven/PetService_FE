import Header from "../components/layout/header/header";
const HomePage = () => {
    return (
        <div>
            <Header />
        </div>
    );
}

export default HomePage;